﻿using ProjetoFolhaPagamento.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoFolhaPagamento.Database
{
    class FuncionarioDAO
    {
        private static List<Funcionario> funcionarios = new List<Funcionario>();

        public static void CadastrarFuncionario(Funcionario f)
        {
            funcionarios.Add(f);
        }
        public static List<Funcionario> RetornarFuncionario()
        {
            return funcionarios;
        }
    }
}
