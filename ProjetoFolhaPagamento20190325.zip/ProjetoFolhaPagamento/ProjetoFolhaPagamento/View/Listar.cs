﻿using ProjetoFolhaPagamento.Database;
using ProjetoFolhaPagamento.Model;
using ProjetoFolhaPagamento.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoFolhaPagamento.View
{
    class Listar
    {
        public static void ListarFolhaDePagamento()
        {
            int cont = 0;
            Console.WriteLine("INFORME O CPF:");
            string cpf = Console.ReadLine();
            Console.WriteLine("INFORME O ANO:");
            int ano = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("INFORME O MÊS:");
            int mes = Convert.ToInt32(Console.ReadLine());

            foreach (var item in FolhaDePagamentoDAO.RetornarFolhaDePagamento())
            {
                if (cpf.Equals(item.Funcionario.Cpf) && ano == item.MesAno.Year && mes == item.MesAno.Month)
                {
                    double bonus = Calculos.RetornaPercentual(item.Cargo.ValorBonus);
                    double salarioBruto = Calculos.SalarioBruto(item.HorasTrabalhadas, item.ValorHora) + bonus;
                    double inss;
                    double fgts = salarioBruto - (salarioBruto * 0.92);
                    Console.WriteLine("Salário Bruto: " + salarioBruto.ToString("C2"));
                    Console.WriteLine("Imposto de renda: ");
                    Console.WriteLine("INSS: ");
                    Console.WriteLine("FGTS: " + fgts.ToString("C2"));
                    Console.WriteLine("Bonûs: " + ((bonus * salarioBruto) - salarioBruto).ToString("C2"));
                    Console.WriteLine("Salário Líquido: ");
                    cont++;
                }
            }
            if (cont == 0) Console.WriteLine("Nenhum registro encontrado");
        }
        public static void ListarFolhaPorCpf()
        { 
            int cont = 0;
            Console.WriteLine("INFORME O CPF:");
            string cpf = Console.ReadLine();
            double salarioTotal = 0;
            foreach (var item in FolhaDePagamentoDAO.RetornarFolhaDePagamento())
            {
                if (cpf.Equals(item.Funcionario.Cpf))
                {
                    double bonus = Calculos.RetornaPercentual(item.Cargo.ValorBonus);
                    double salarioBruto = Calculos.SalarioBruto(item.HorasTrabalhadas, item.ValorHora) + bonus;
                    double inss = 0;
                    double ir = 0;
                    double fgts = salarioBruto - (salarioBruto * 0.92);
                    double salarioLiquido = salarioBruto - inss - ir;

                    Console.WriteLine("___________________________________");
                    Console.WriteLine("Nome Funcionário: " + item.Funcionario.Nome);
                    Console.WriteLine("Cargo Funcionário: " + item.Cargo.Nome);
                    Console.WriteLine("Período referente: " + item.MesAno.Month+"/"+item.MesAno.Year);
                    Console.WriteLine("\tSalário Bruto: " + salarioBruto.ToString("C2"));
                    Console.WriteLine("\tImposto de renda: ");
                    Console.WriteLine("\tINSS: ");
                    Console.WriteLine("\tFGTS: " + fgts.ToString("C2"));
                    Console.WriteLine("\tBonûs: " + ((bonus * salarioBruto) - salarioBruto).ToString("C2"));
                    Console.WriteLine("Salário Líquido: ");

                    salarioTotal += salarioLiquido;
                    cont++;
                }
            }
            if (cont == 0) Console.WriteLine("Nenhum registro encontrado!");
            else
            {
                Console.WriteLine("**************************");
                Console.WriteLine("Salário Total: " + salarioTotal);
                Console.WriteLine("**************************");
            }
        }
        public static void ListarPorData()
        {
            int cont = 0;
            Console.WriteLine("Informe o Ano: ");
            int ano = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Informe o Mês: ");
            int mes = Convert.ToInt32(Console.ReadLine());
            double salarioTotal = 0;

            foreach (var item in FolhaDePagamentoDAO.RetornarFolhaDePagamento())
            {
                if ( item.MesAno.Year == ano && item.MesAno.Month == mes)
                {
                    double bonus = Calculos.RetornaPercentual(item.Cargo.ValorBonus);
                    double salarioBruto = Calculos.SalarioBruto(item.HorasTrabalhadas, item.ValorHora) + bonus;
                    double inss = 0;
                    double ir = 0;
                    double fgts = salarioBruto - (salarioBruto * 0.92);
                    double salarioLiquido = salarioBruto - inss - ir;

                    Console.WriteLine("___________________________________");
                    Console.WriteLine("Nome Funcionário: " + item.Funcionario.Nome);
                    Console.WriteLine("Cargo Funcionário: " + item.Cargo.Nome);
                    Console.WriteLine("Período referente: " + item.MesAno.Month + "/" + item.MesAno.Year);
                    Console.WriteLine("\tSalário Bruto: " + salarioBruto.ToString("C2"));
                    Console.WriteLine("\tImposto de renda: ");
                    Console.WriteLine("\tINSS: ");
                    Console.WriteLine("\tFGTS: " + fgts.ToString("C2"));
                    Console.WriteLine("\tBonûs: " + ((bonus * salarioBruto) - salarioBruto).ToString("C2"));
                    Console.WriteLine("Salário Líquido: ");

                    salarioTotal += salarioLiquido;
                    cont++;
                }
                if (cont == 0) Console.WriteLine("Nenhum registro encontrado!");
                else
                {
                    Console.WriteLine("**************************");
                    Console.WriteLine("Salário Total: " + salarioTotal);
                    Console.WriteLine("**************************");
                }
            }

        }
    }
}
