﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoFolhaPagamento.View
{
    class Menu
    {
        public static void Imprimir()
        {
            Console.WriteLine("  -- VENDAS -- \n");
            Console.WriteLine("1 - Cadastrar cargo");
            Console.WriteLine("2 - Cadastrar funcionário");
            Console.WriteLine("3 - Cadastrar folha de pagamento");
            Console.WriteLine("4 - Consultar folha de pagamento");
            Console.WriteLine("5 - Consultar histórico de folhas de pagamento do funcionário");
            Console.WriteLine("6 - Consultar histórico de folhas de pagamento do mês");
            Console.WriteLine("0 - Sair\n");
        }
        public static void Finalizar()
        {
            Console.WriteLine("***************************************");
            Console.WriteLine("Programa encerrado");
            Console.ReadKey();
        }
    }
}
