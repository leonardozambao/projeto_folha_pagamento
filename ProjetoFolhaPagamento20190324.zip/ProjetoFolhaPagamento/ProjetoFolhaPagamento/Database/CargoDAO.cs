﻿using ProjetoFolhaPagamento.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoFolhaPagamento.Database
{
    class CargoDAO
    {
        private static List<Cargo> cargos = new List<Cargo>();

        public static void CadastrarCargo(Cargo c)
        {
            cargos.Add(c);
        }
        public static List<Cargo> RetornarCargo()
        {
            return cargos;
        }
    }
}
