﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoFolhaPagamento.Util
{
    class Calculos
    {
        public static double RetornaPercentual(double bonus)
        {
            return (1 + (bonus / 100));
        }
        public static double SalarioBruto(int horasTrabalhadas, double valorHora)
        {
            return horasTrabalhadas * valorHora;
        }
    }
}
