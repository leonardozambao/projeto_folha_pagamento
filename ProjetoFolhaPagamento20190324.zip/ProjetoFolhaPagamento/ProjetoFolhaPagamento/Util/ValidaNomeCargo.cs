﻿using ProjetoFolhaPagamento.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoFolhaPagamento.Util
{
    class ValidaNomeCargo
    {
        public static Boolean UnicoCargo(string nome)
        {
            Boolean cargoUnico = true;
            foreach (var item in CargoDAO.RetornarCargo())
            {
                if (nome.Equals(item.Nome, StringComparison.InvariantCultureIgnoreCase))
                {
                    cargoUnico = false;
                    break;
                }
            }
            if (!cargoUnico) return false;
            else return true;
        }
    }
}