﻿using ProjetoFolhaPagamento.Database;
using ProjetoFolhaPagamento.Model;
using ProjetoFolhaPagamento.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoFolhaPagamento
{
    class Program
    {
        static void Main(string[] args)
        {
            DatabaseDefault.IniciaDatabase();
            Boolean continuar = true;
            string op;

            do
            {
                Menu.Imprimir();
                op = Console.ReadLine();
                Console.Clear();
                switch (op)
                {
                    case "0":
                        continuar = false;
                        break;
                    case "1":
                        Cadastrar.CadastrarCargo();
                        break;
                    case "2":
                        Cadastrar.CadastrarFuncionario();
                        break;
                    case "3":
                        Cadastrar.CadastrarFolhaDePagamento();
                        break;
                    case "4":
                        Listar.ListarFolhaDePagamento();
                        break;
                    case "5":
                        break;
                    default:
                        Console.WriteLine("Opção inválida!");
                        break;
                }
            } while (continuar);
            
            Menu.Finalizar();
        }
    }
}
