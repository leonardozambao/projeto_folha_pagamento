﻿using ProjetoFolhaPagamento.Database;
using ProjetoFolhaPagamento.Model;
using ProjetoFolhaPagamento.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoFolhaPagamento.View
{
    class Listar
    {
        public static void ListarFolhaDePagamento()
        {
            int cont = 0;
            Console.WriteLine("INFORME O CPF:");
            string cpf = Console.ReadLine();
            Console.WriteLine("INFORME O ANO:");
            int ano = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("INFORME O MÊS:");
            int mes = Convert.ToInt32(Console.ReadLine());

            foreach (var item in FolhaDePagamentoDAO.RetornarFolhaDePagamento())
            {
                if (cpf.Equals(item.Funcionario.Cpf) && ano == item.MesAno.Year && mes == item.MesAno.Month)
                {
                    double bonus = Calculos.RetornaPercentual(item.Cargo.ValorBonus);
                    double salarioBruto = Calculos.SalarioBruto(item.HorasTrabalhadas, item.ValorHora);
                    Console.WriteLine("Salário Bruto: " + salarioBruto);
                    Console.WriteLine("Bonûs: " + bonus);
                    cont++;
                }
            }
            if (cont == 0) Console.WriteLine("Nenhum registro encontrado");
        }
    }
}
