﻿using ProjetoFolhaPagamento.Database;
using ProjetoFolhaPagamento.Model;
using ProjetoFolhaPagamento.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoFolhaPagamento.View
{
    class Cadastrar
    {
        public static void CadastrarCargo()
        {
            Cargo c = new Cargo(); 
            Console.WriteLine("-- CADASTRAR CARGO --");
            Console.WriteLine("INFORME O NOME DO CARGO:");
            c.Nome = Console.ReadLine();
            ValidaNomeCargo.UnicoCargo(c.Nome);
            if (!ValidaNomeCargo.UnicoCargo(c.Nome)) Console.WriteLine("CARGO JÁ EXISTE!");
            else
            {
                Console.WriteLine("INFORME O VALOR DO BONUS:");
                c.ValorBonus = Convert.ToDouble(Console.ReadLine());
                CargoDAO.CadastrarCargo(c);
                Console.WriteLine("Cargo cadastrado com sucesso!");
            }   
        }
        public static void CadastrarFuncionario()
        {
            Funcionario f = new Funcionario();
            Console.WriteLine("-- CADASTRAR FUNCIONARIO --");
            Console.WriteLine("INFORME O NOME:");
            f.Nome = Console.ReadLine();
            Console.WriteLine("INFORME O CPF:");
            f.Cpf = Console.ReadLine();
            if (!ValidaCpf.valida(f.Cpf)) Console.WriteLine("CPF INVÁLIDO!");
            else if (!ValidaCpf.CpfUnico(f.Cpf)) Console.WriteLine("CPF já cadastrado!");
            else
            {
                Console.WriteLine("INFORME A DATA DE NASCIMENTO: (DD/MM/YYYY)");
                f.DataNasc = Convert.ToDateTime(Console.ReadLine());
                FuncionarioDAO.CadastrarFuncionario(f);
                Console.WriteLine("Funcionário cadastrado com sucesso!");
            }   
        }
        public static void CadastrarFolhaDePagamento()
        {
            FolhaDePagamento fp = new FolhaDePagamento();
            Console.WriteLine("-- CADASTRAR FOLHA DE PAGAMENTO --");
            Console.WriteLine("INFORME O CPF DO FUNCIONÁRIO: ");
            fp.Funcionario.Cpf = Console.ReadLine();
            if (ValidaCpf.CpfUnico(fp.Funcionario.Cpf)) Console.WriteLine("CPF inexistente!");
            else
            {
                Console.WriteLine("INFORME O NOME DO CARGO: ");
                fp.Cargo.Nome = Console.ReadLine();
                if (ValidaNomeCargo.UnicoCargo(fp.Cargo.Nome)) Console.WriteLine("Cargo inexistente!");
                else
                {
                    Console.WriteLine("Informe o ANO do pagamento: ");
                    int ano = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Informe o MÊS do pagamento: ");
                    int mes = Convert.ToInt32(Console.ReadLine());
                    if (!ValidaMesAno.MesAnoUnico(ano, mes, fp.Funcionario.Cpf))
                    {
                        Console.WriteLine("JÁ EXISTE UMA FOLHA PARA ESSE MÊS/ANO REGISTRADO NESTE CPF");
                    }
                    else
                    { 
                        fp.MesAno = new DateTime(ano, mes, 1).AddMonths(1).AddDays(-1);
                        Console.WriteLine("Informe o número de horas trabalhadas: ");
                        fp.HorasTrabalhadas = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Informe o valor da hora: ");
                        fp.ValorHora = Convert.ToDouble(Console.ReadLine());
                        FolhaDePagamentoDAO.CadastrarFolhaDePagamento(fp);
                        Console.WriteLine("Folha de pagamento registrada com sucesso!");
                    }
                }
            }
        }
    }
}
