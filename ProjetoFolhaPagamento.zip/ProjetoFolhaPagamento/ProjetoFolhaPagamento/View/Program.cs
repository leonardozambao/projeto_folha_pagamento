﻿using ProjetoFolhaPagamento.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoFolhaPagamento
{
    class Program
    {
        static void Main(string[] args)
        {
            Boolean continuar = true;
            string op;

            do
            {
                Menu.Imprimir();
                op = Console.ReadLine();
                Console.Clear();
                switch (op)
                {
                    case "1":
                        Cadastrar.CadastrarCargo();
                        break;
                    case "2":

                        break;
                    case "3":

                        break;
                    case "4":

                        break;
                    case "5":

                        break;
                    case "6":

                        break;
                    case "0":
                        continuar = false;
                        Console.WriteLine("Saindo...");
                        break;
                    default:
                        Console.WriteLine("Opção inválida!");
                        break;
                }
            } while (continuar);
            
            Menu.Finalizar();
        }
    }
}
