﻿using ProjetoFolhaPagamento.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoFolhaPagamento.Util
{
    class ValidaNomeCargo
    {
        public static Boolean UnicoProduto(string nome)
        {
            Boolean nomeUnico = true;
            foreach (var item in CargoDAO.RetornarProduto())
            {
                if (nome.Equals(item.Nome, StringComparison.InvariantCultureIgnoreCase))
                {
                    nomeUnico = false;
                    break;
                }
            }
            if (!nomeUnico)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
