﻿using ProjetoFolhaPagamento.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoFolhaPagamento.Database
{
    class DatabaseDefault
    {
        public static void IniciaDatabase()
        {
            Cargo c = new Cargo();
            Funcionario f = new Funcionario();
            c.Nome = "DBA";
            c.ValorBonus = 15;
            f.Cpf = "11418205958";
            f.DataNasc = Convert.ToDateTime("16/02/1998");
            f.Nome = "Leonardo";
            Cargo c2 = new Cargo();
            Funcionario f2 = new Funcionario();
            c2.Nome = "teste";
            c2.ValorBonus = 10;
            f2.Cpf = "12345678909";
            f2.DataNasc = Convert.ToDateTime("23/03/2019");
            f2.Nome = "Zambão";

            FolhaDePagamento fp = new FolhaDePagamento();
            fp.Cargo.Nome = c.Nome;
            fp.Funcionario.Cpf = f.Cpf;
            fp.HorasTrabalhadas = 160;
            fp.MesAno = new DateTime(2019, 3, 1).AddMonths(1).AddDays(-1);
            fp.ValorHora = 35;
            fp.Cargo.ValorBonus = c.ValorBonus;
            fp.Funcionario.Nome = f.Nome;

            FuncionarioDAO.CadastrarFuncionario(f);
            FuncionarioDAO.CadastrarFuncionario(f2);
            CargoDAO.CadastrarCargo(c);
            CargoDAO.CadastrarCargo(c2);
            FolhaDePagamentoDAO.CadastrarFolhaDePagamento(fp);
        }
    }
}
