﻿using ProjetoFolhaPagamento.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoFolhaPagamento.Database
{
    class FolhaDePagamentoDAO
    {
        private static List<FolhaDePagamento> folhas = new List<FolhaDePagamento>();

        public static void CadastrarFolhaDePagamento(FolhaDePagamento fp)
        {
            folhas.Add(fp);
        }
        public static List<FolhaDePagamento> RetornarFolhaDePagamento()
        {
            return folhas;
        }
    }
}
