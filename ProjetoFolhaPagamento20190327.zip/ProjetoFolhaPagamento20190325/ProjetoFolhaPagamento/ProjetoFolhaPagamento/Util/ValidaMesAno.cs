﻿using ProjetoFolhaPagamento.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoFolhaPagamento.Util
{
    class ValidaMesAno
    {
        
        public static Boolean MesAnoUnico(int ano, int mes, string cpf)
        {
            Boolean unico = true;
            foreach (var item in FolhaDePagamentoDAO.RetornarFolhaDePagamento())
            {
                if (ano == item.MesAno.Year && mes == item.MesAno.Month)
                {
                    if (!ValidaCpf.CpfRegistradoFolha(cpf)) unico = false;
                }
            }
            if (!unico) return false;
            else return unico;
        }
        
    }
}
