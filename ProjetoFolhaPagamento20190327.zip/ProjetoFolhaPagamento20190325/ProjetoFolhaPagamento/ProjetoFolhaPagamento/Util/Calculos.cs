﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoFolhaPagamento.Util
{
    class Calculos
    {
        public static double RetornaPercentual(double bonus)
        {
            return (1 + (bonus / 100));
        }
        public static double SalarioBruto(int horasTrabalhadas, double valorHora)
        {
            return horasTrabalhadas * valorHora;
        }
        public static double RetornaInss(double salarioBruto)
        {
            double inss;
            if (salarioBruto <= 1693.72)
            {
                inss = salarioBruto * 0.08;
                return inss;
            }
            else if (salarioBruto <= 2822.90)
            {
                inss = salarioBruto * 0.09;
                return inss;
            }
            else if (salarioBruto <= 5645.80)
            {
                inss = salarioBruto * 0.11;
                return inss;
            }
            else
            {
                inss = 621.03;
                return inss;
            }
        }
        public static double RetornaIR(double salarioBruto)
        {
            double ir;
            if (salarioBruto <= 1903.98)
            {
                return 0;
            }
            else if (salarioBruto <= 2826.65)
            {
                return ir = (salarioBruto * 0.075) - 142.80;
            }
            else if(salarioBruto <= 3751.05)
            {
                return ir = (salarioBruto * 0.15) - 354.80;
            }
            else if (salarioBruto <= 4664.68)
            {
                return ir = (salarioBruto * 0.225) - 636.13;
            }
            else
            {
                return ir = (salarioBruto * 0.275) - 869.36;
            }
        }
    }
}
